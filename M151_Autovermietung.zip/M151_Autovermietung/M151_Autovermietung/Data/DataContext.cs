﻿using M151_Autovermietung.Modell;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace M151_Autovermietung.Data
{
    public class DataContext : IdentityDbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }

        public DbSet<Kunde> Kunde { get; set; }
        public DbSet<Auto> Auto { get; set; }
        public DbSet<Miete> Miete { get; set; }
        public DbSet<Preis> Preis{get; set; }
    }
}